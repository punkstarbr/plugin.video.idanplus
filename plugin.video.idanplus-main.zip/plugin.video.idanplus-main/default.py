# -*- coding: utf-8 -*-
from sys import argv
from resources.main import route

route(argv[2])